#include<actas.h>
#include<utilitarias.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>

void generar_acta_res(const char * path_alus, const char * path_notas, const char * path_acta, const char * path_obs)
{

}
