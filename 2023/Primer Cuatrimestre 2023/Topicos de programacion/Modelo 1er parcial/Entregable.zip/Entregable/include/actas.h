#ifndef ACTAS_H_INCLUDED
#define ACTAS_H_INCLUDED

void generar_acta(const char * path_alus, const char * arch_notas, const char * arch_acta, const char * arch_obs);
void generar_acta_res(const char * path_alus, const char * arch_notas, const char * arch_acta, const char * arch_obs);

#endif // BANCO_H_INCLUDED
