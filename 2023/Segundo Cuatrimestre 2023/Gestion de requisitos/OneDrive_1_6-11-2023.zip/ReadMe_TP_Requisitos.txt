NOTAS:
Revisar: 
AIR PATAGONIA
* Casos de uso 4# REGISTRAR DESPACHOS deberia de revisarse
PARTIDAZO
* Drawio hay un detalle con la interfaz tentativa de Partidazo del caso de uso 'Reservar Cancha' -> Falta un componente.
* Casos de uso 1# RESERVAR CANCHA entiendo estaria completo, hay que ver si faltan flujos alternativos o detalles.
